# sorting 

class Foo:
    def __init__(self,v,f):
        self.v = v
        self.f = f
        
    def __lt__(self,other):
        return self.f < other.f or (self.f == other.f and self.v < other.v)

def customSort(arr):
    h = {}
    for x in arr:
        if x not in h:
            h[x] = 1
        else: h[x] += 1
    for i in range(len(arr)):
        arr[i] = Foo(arr[i],h[arr[i]])
    arr.sort()
    for x in arr: print(x.v)


# gandalf

def minPower(p):
    min = 0
    sum = 0
    for x in p:
        sum += x
        if sum < min: min = sum
    if min >= 0: return 0
    return 1-min


# caretaker

def efficientCaretaker(weight):
    weight.sort(reverse = True)
    n = 0
    while len(weight) > 0:
        tot = 3
        i = 0
        while True:
            if weight[i] <= tot:
                tot -= weight[i]
                weight.pop(i)
            else: i += 1
            if i >= len(weight) or tot == 0:
                n += 1
                break
    return n


# longest subsequence

v = ["a","e","i","o","u"]

def longestSubsequence(s):
    i = s.find("a")
    if i < 0: return 0
    j = s.rfind("u")
    if j < 0: return 0
    res = DPBU(s[i:j+1])
    if res: return res
    return 0

memo = {}

def DPBU(s):
    for lo in range(len(s),-1,-1):
        for let in range(4,-1,-1):
            if lo == len(s):
                if let == 4: memo[(lo,let)] = 0
                else: memo[(lo,let)] = None
            elif v[let] == s[lo]:
                memo[(lo,let)] = myPlus(memo[(lo+1,let)],1)            
            elif let == 4 or s[lo] != v[let+1] or lo==0: 
                memo[(lo,let)] = memo[(lo+1,let)]
            else:
                recWithout = memo[(lo+1,let)]
                recWith = memo[(lo,let+1)]
                memo[(lo,let)] = myMax(recWithout,recWith)
    return memo[(0,0)]
    
def myPlus(a,b):
    if a != None: return a+b
    return None
    
def myMax(a,b):
    if a != None:
        if b != None and b>a: return b
        return a
    return b
    

# animals

def angryAnimals(n, a, b):
    e = [None for i in range(n)] 
    for i in range(len(a)):
        if a[i] > b[i]:
            if e[a[i]-1] == None or e[a[i]-1]<b[i]: e[a[i]-1] = b[i]
        elif e[b[i]-1] == None or e[b[i]-1]<a[i]: e[b[i]-1] = a[i]
    lo = hi = 1
    count = 0
    while lo <= n:
        if hi < n and group(lo,hi,e): hi += 1
        else: 
            count += hi + 1 -lo
            if lo == hi: hi += 1
            lo += 1
    return count

def group(lo,hi,e):
    if e[hi] == None or e[hi]<lo: return True
    return False


# strokes

def strokesRequired(picture):
    h = len(picture)
    w = len(picture[0])
    remain = set()
    for i in range(h):
        for j in range(w):
            remain.add((i,j))
    count = 0
    while len(remain) > 0:
        count += 1
        front = {remain.pop()}
        while len(front) > 0:
            (i,j) = front.pop()
            if i > 0 and (i-1,j) in remain and picture[i][j] == picture[i-1][j]:
                    front.add((i-1,j))
                    remain.remove((i-1,j))
            if i < h-1 and (i+1,j) in remain and picture[i][j] == picture[i+1][j]:
                    front.add((i+1,j))
                    remain.remove((i+1,j))
            if j > 0 and (i,j-1) in remain and picture[i][j] == picture[i][j-1]:
                    front.add((i,j-1))
                    remain.remove((i,j-1))
            if j < w-1 and (i,j+1) in remain and picture[i][j] == picture[i][j+1]:
                    front.add((i,j+1))
                    remain.remove((i,j+1))
    return count  
