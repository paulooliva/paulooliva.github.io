#!/bin/python3

import math
import os
import random
import re
import sys

def minPower(p):
   s = 0; m = 0
   for i in range(len(p)):
      s = s + p[i]
      if s < m: m = s
   return 1 - m if m <= 0 else 0

if __name__ == '__main__':
    p_count = int(input().strip())

    p = []

    for _ in range(p_count):
        p_item = int(input().strip())
        p.append(p_item)

    result = minPower(p)

    print(result)
