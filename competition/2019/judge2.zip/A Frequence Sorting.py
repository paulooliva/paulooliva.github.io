#!/bin/python3

import math
import os
import random
import re
import sys

def customSort(arr):
   # Write your code here
   arr_u = list(set(arr))
   arr_occur = [ (len([ i for i in arr if i == n]), n) for n in arr_u ]
   arr_occur = sorted(arr_occur)
   for c, n in arr_occur:
      for i in range(c):
         print(n)

if __name__ == '__main__':
   arr_count = int(input().strip())

   arr = []

   for _ in range(arr_count):
     arr_item = int(input().strip())
     arr.append(arr_item)

   customSort(arr)