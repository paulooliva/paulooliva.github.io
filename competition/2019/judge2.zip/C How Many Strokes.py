#!/bin/python3

import math
import os
import random
import re
import sys

def id_strokes(pic, n, m, s1, s2):
   for i in range(n):
      for j in range(m):
         if pic[i][j]['stroke'] == s2:
            pic[i][j]['stroke'] = s1

# The function accepts STRING_ARRAY picture as parameter.
# The function is expected to return an INTEGER.

def strokesRequired(picture):
   n = len(picture)
   m = len(picture[0])
   pic = []
   # convert array into dictionary
   for i in range(n):
      s = []
      for j in range(m):
         s.append({
            'stroke' : None,
            'char' : picture[i][j],
         })
      pic.append(s)
   # scan array and calculate strokes
   stroke = 1
   for i in range(n):
      for j in range(m):
         # has character above and left, and all are the same
         if i > 0 and j > 0 and pic[i-1][j]['char'] == pic[i][j-1]['char'] and pic[i-1][j]['char'] == pic[i][j]['char']:
            if pic[i-1][j]['stroke'] != pic[i][j-1]['stroke']:
               # make pic[i-1][j]['stroke'] the same as pic[i][j-1]['stroke']
               id_strokes(pic, i+1, m, pic[i-1][j]['stroke'], pic[i][j-1]['stroke'])
            pic[i][j]['stroke'] = pic[i-1][j]['stroke']
         # has character above and is the same
         elif i > 0 and pic[i-1][j]['char'] == pic[i][j]['char']:
            pic[i][j]['stroke'] = pic[i-1][j]['stroke']
         # has character on left and is the same
         elif j > 0 and pic[i][j-1]['char'] == pic[i][j]['char']:
            pic[i][j]['stroke'] = pic[i][j-1]['stroke']
         # has no characters above or to the left, or is a different character
         else:
            # use a new stroke
            pic[i][j]['stroke'] = stroke
            stroke = stroke + 1
      # print_canvas(pic, n, m)
   ss = []
   # count different strokes
   for i in range(n):
      for j in range(m):
         if pic[i][j]['stroke'] not in ss:
            ss.append(pic[i][j]['stroke'])

   return len(ss)

if __name__ == '__main__':
    picture_count = int(input().strip())

    picture = []

    for _ in range(picture_count):
        picture_item = input()
        picture.append(picture_item)

    result = strokesRequired(picture)

    print(result)
