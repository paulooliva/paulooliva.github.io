#!/bin/python3

import math
import os
import random
import re
import sys

#
# Complete the 'longestSubsequence' function below.
#
# The function is expected to return an INTEGER.
# The function accepts STRING s as parameter.
#

def longestSubsequence(s):
   # convert to list of integers
   s = s.replace('a','0')
   s = s.replace('e','1')
   s = s.replace('i','2')
   s = s.replace('o','3')
   s = s.replace('u','4')
   n = len(s)
   ns = [ int(c) for c in list(s) ]
   # build a dynamic programming memory
   # length of longest sequence ending at each number
   m = [0,0,0,0,0]
   for i in range(n):
      # longest sequence ending at i
      if ns[i] == 0:
         m[ns[i]] = 1 + m[ns[i]]
      else:
         # means that a sequence with the previous letter exists and can be extended
         if m[ns[i]-1] != 0:
            if m[ns[i]-1] > m[ns[i]]:
               m[ns[i]] = 1 + m[ns[i]-1]
            else:
               m[ns[i]] = 1 + m[ns[i]]
   return m[4]

if __name__ == '__main__':
    s = input()

    result = longestSubsequence(s)

    print(result)
