#!/bin/python3

import math
import os
import random
import re
import sys

def angryAnimals(n, a, b):
   c = 0
   # calculate minimal enemy pairs
   enemy = {}
   for l in range(len(a)):
      i = max(a[l], b[l])
      j = min(a[l], b[l])
      if i not in enemy:
         enemy[i] = j
      else:
         enemy[i] = max(enemy[i], j)
   # calculate by dynamic programming
   total = 0  # total groups so far
   k = 1      # last enemy
   for i in range(1,n+1):
      if i in enemy and enemy[i] >= k:
         k = enemy[i] + 1
      print('Adding',i-k+1,'groups', (k,i))
      total += i-k+1
   return total

if __name__ == '__main__':
    n = int(input().strip())
    a_count = int(input().strip())
    a = []

    for _ in range(a_count):
        a_item = int(input().strip())
        a.append(a_item)

    b_count = int(input().strip())
    b = []
    for _ in range(b_count):
        b_item = int(input().strip())
        b.append(b_item)

    result = angryAnimals(n, a, b)
    print(result)
