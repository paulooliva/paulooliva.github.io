#!/bin/python3

import math
import os
import random
import re
import sys

def efficientCaretaker(weight):
   xs = sorted(weight, reverse=True)
   i = 0; j = len(xs) - 1
   while i < j:
      # can take two bags
      if xs[i] + xs[j] <= 3.0: j = j - 1
      i = i + 1
   return i + 1 if i == j else i

if __name__ == '__main__':
    weight_count = int(input().strip())

    weight = []

    for _ in range(weight_count):
        weight_item = float(input().strip())
        weight.append(weight_item)

    result = efficientCaretaker(weight)

    print(result)
