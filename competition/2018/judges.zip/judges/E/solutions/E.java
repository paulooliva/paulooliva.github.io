/* Author: Nikos Tzevelekos (10/02/2018)
   Solution to problem E 
   EECS Programming Competition */

import java.util.Scanner;

public class E {

    public static int foo(Scanner inp) {
        int lines = inp.nextInt();

        int first=1, last=1, middle=1;
        int negs=0, pivot=0;
        

        for (int i=0; i<lines; i++) {
            int n = inp.nextInt();
            if (negs==0) {
                if (n<0) { pivot = n; negs=1; } 
                else first = first*n;
            }
            else if (negs==1) {
                if (n<0) { negs=2; first = first*pivot; last=n; } 
                else middle = middle*n;
            }
            else {
                if (n<0) { middle = middle*last; last=n; } 
                else last = last*n;
            }
        }
        if (negs==0) return first;
        if (negs==1) return Math.max(first,middle);
        if (middle>0) return first*middle*last;
        return Math.max(first*middle,middle*last);
    }

    
    public static void main(String args[]) {

        Scanner inp = new Scanner(System.in);     
        System.out.println(foo(inp));
    }
}
