-- Author: Paulo Oliva (10/02/2018)
-- Solution to problem E
-- EECS Programming Competition

-- Note: This is an O(n^3) solution so does not pass all
-- the test cases within the 2 sec time limit.

import Data.List

main = do
   let readNumber = getLine >>= return . read
   n <- readNumber
   ns <- sequence (replicate n readNumber)
   let l = length ns
   print $ maximum [ product . drop i . take j $ ns | i <- [0..l], j <- [0..(l-i)] ]
