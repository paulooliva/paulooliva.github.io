/* Author: Nikos Tzevelekos (10/02/2018)
   Solution to problem F 
   EECS Programming Competition */

import java.util.Scanner;

public class F {

    public static String foo(Scanner inp) {
        String[] lines = new String[5];
        for (int i=0; i<5; i++) lines[i] = inp.next();
        int all = lines[0].length()/7;
        String out = "";
        for (int i=0; i<all; i++) {
            if (lines[0].charAt(7*i+1)=='.') out+=1;
            else if (lines[3].charAt(7*i+1)=='#') out+=2;
            else if (lines[4].charAt(7*i+1)=='.') out+=4;
            else if (lines[1].charAt(7*i+1)=='.') out+=3;
            else out+=5;
        }
        return out;
    }

    public static void main(String args[]) {

        Scanner inp = new Scanner(System.in);     
        System.out.println(foo(inp));
    }
}
