-- Author: Paulo Oliva (10/02/2018)
-- Solution to problem F 
-- EECS Programming Competition

import Data.List

split :: String -> [String]
split "" = []
split xs = (take 7 xs):(split $ drop 7 xs)

readLine :: IO [String]
readLine = getLine >>= return . split

-- enough to look at the second column to determine the digit
decode :: String -> Int
decode "....." = 1
decode "#.###" = 2
decode "#.#.#" = 3
decode "###.." = 4
decode "###.#" = 5

combine xs | head xs == [] = []
           | otherwise = (map ((!!1).head) xs):(combine $ map tail xs)

main = do
   ls <- sequence (replicate 5 readLine)
   let ds = (map decode) . combine $ ls
   putStrLn . concat . map show $ ds
