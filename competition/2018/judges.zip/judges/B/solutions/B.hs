-- Author: Paulo Oliva (10/02/2018)
-- Solution to problem B 
-- EECS Programming Competition

import Data.List

readPhone :: IO [Int]
readPhone = getLine >>= return . read . (++"]") . ('[':) . intersperse ','

test :: Int -> ([Int] -> Bool) -> [Int] -> Bool
test n f xs | length xs < n = False
            | f $ take n xs = True
            | otherwise = test n f (tail xs)

all_equal (x:xs) = and $ map (==x) xs

all_equal_non_zero xs = (head xs /= 0) && (all_equal xs)

iden = test 3 all_equal

palin ns n = test n (\xs -> xs == reverse xs) ns

prog = test 3 (\xs -> all_equal_non_zero (zipWith (-) xs (tail xs)))

main = do
   ns <- readPhone
   if length ns /= 11 then -- check correct input
      putStrLn $ "Input of wrong length: " ++ (show ns)
   else do
      let t1 = iden ns -- check if three identical numbers
      let t2 = or (map (palin ns) [5,6]) -- check palindrome: enough to check lenghts 5 and 6
      let t3 = prog ns -- arithmetic progression
      let passed = length $ filter (==True) [t1,t2,t3]
      putStrLn $ if passed >= 2 then "Yes" else "No"
