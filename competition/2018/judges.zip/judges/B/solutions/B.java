/* Author: Nikos Tzevelekos (10/02/2018)
   Solution to problem B
   EECS Programming Competition */

import java.util.Scanner;
import java.util.Arrays;

public class B {

    public static String foo(Scanner inp) {
        char[] num = inp.next().toCharArray();
        int c=0;
        
        for (int i=0; i<num.length-2; i++) 
            if (num[i]==num[i+1] && num[i+1]==num[i+2]) {
                    c++; break;
                }
        for (int i=0; i<num.length-2; i++) 
            if (2*num[i+1]==num[i]+num[i+2]) {
                    c++; break;
                }
        if (c==2) return "Yes";
        for (int i=0; i<num.length-4; i++) 
            if (num[i]==num[i+4] && num[i+1]==num[i+3]) {
                    c++; break;
                }     
        if (c==2) return "Yes";
        return "No";
    }

    
    public static void main(String args[]) {

        Scanner inp = new Scanner(System.in);     
        System.out.println(foo(inp));
    }
}
