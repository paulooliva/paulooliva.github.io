/* Author: Nikos Tzevelekos (10/02/2018)
   Solution to problem A 
   EECS Programming Competition */

import java.util.Scanner;
import java.util.Arrays;

public class A {

    public static String foo(Scanner inp) {
        int lines = inp.nextInt();
        int[] heights = new int[lines];

        for (int i=0; i<lines; i++) {
            inp.next();
            String s = inp.next();
            s = s.substring(0,s.length()-1);
            heights[i] = (int)(Double.parseDouble(s) * 100);
        }

        Arrays.sort(heights);

        for (int i=0; i<lines; i+=2) 
            if (heights[i+1]-heights[i]>2) return "No";

        return "Yes";
    }

    
    public static void main(String args[]) {

        Scanner inp = new Scanner(System.in);     
        System.out.println(foo(inp));
    }
}
