-- Author: Paulo Oliva (10/02/2018)
-- Solution to problem A
-- EECS Programming Competition

import Data.List

readNumber :: IO Int
readNumber = getLine >>= return . read

readHeight :: IO Float
readHeight = getLine >>= return . read . tail . init . (dropWhile (/=' '))

f :: [Float] -> [(Float,Float)]
f [] = []
f (x:y:zs) = (y,x):(f zs)

main = do
   n <- readNumber
   if n < 2 || n > 10000 then
      print $ "Invalid input: " ++ (show n)
   else do
      hs' <- sequence (replicate n readHeight)
      let hs = f $ sort hs'
      let test = and . map (<=0.02) $ map (uncurry (-)) $ hs
      putStrLn $ if test then "Yes" else "No"
