/* Author: Nikos Tzevelekos (10/02/2018)
   Solution to problem D 
   EECS Programming Competition */

import java.util.Scanner;

public class D {

    public static final int[] coins = {200, 100, 50, 20, 10, 5, 2, 1};
    
    public static int foo(int x, int acc) {
        for (int i=0; i<coins.length; i++) 
            if (x>=coins[i]) return foo(x-coins[i],acc+1);
        return acc;
    }

    
    public static void main(String args[]) {

        Scanner inp = new Scanner(System.in);
        String t = inp.nextLine();
        int x = t.charAt(1)*100+t.charAt(3)*10+t.charAt(4)-111*'0';
        x = foo(x,0);
        if (x==1) System.out.println("1 coin is needed to make "+t);
        else System.out.println(x+" coins are needed to make "+t);
    }
}
