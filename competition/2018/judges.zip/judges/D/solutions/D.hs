-- Author: Paulo Oliva (10/02/2018)
-- Solution to problem D
-- EECS Programming Competition

main = do
   s <- getLine
   let n = round . (100.0*) . read . tail $ s
   let f (v,i) c = (mod v c, i + div v c)
   let (v,i) = foldl f (n,0) [200,100,50,20,10,5,2,1]
   let txt = if i==1 then " coin is " else " coins are "
   putStrLn $ (show i) ++ txt ++ "needed to make " ++ s
