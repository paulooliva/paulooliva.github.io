/* Author: Nikos Tzevelekos (10/02/2018)
   Solution to problem C 
   EECS Programming Competition */

import java.util.Scanner;
import java.util.TreeSet;

public class C {

    public static String foo(Scanner inp) {
        int num = inp.nextInt();
        String bug = inp.next();
        inp.nextLine();
        String[][] libs = new String[num][12];
        
        for (int i=0; i<num; i++) {
            String[] line = inp.nextLine().split("\\s");
            for (int j=0; j<line.length; j++) 
                libs[i][j]=line[j];}

        TreeSet<String> queue = new TreeSet<String>();
        queue.add(bug);
        TreeSet<String> buggy = new TreeSet<String>();

        while (!queue.isEmpty()) {
            String next = queue.first();
            queue.remove(next);
            for (int i=0; i<num; i++)
                for (int j=2; j<12 && libs[i][j]!=null; j++) 
                    if (libs[i][j].equals(next)) {
                        queue.add(libs[i][0]);
                        buggy.add(libs[i][0]);
                        break;
                    }
        }

        String out="";
        if (buggy.isEmpty())
            out = "A bug in library "+bug+" will not break any other libraries.";
        else {
            for (String s : buggy) out = out+","+s;
            out = "A bug in library "+bug+" will break libraries: "+out.substring(1);
        }
        return out;
    }

    
    public static void main(String args[]) {

        Scanner inp = new Scanner(System.in);     
        System.out.println(foo(inp));
    }
}
