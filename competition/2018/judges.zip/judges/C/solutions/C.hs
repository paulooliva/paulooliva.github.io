-- Author: Paulo Oliva (10/02/2018)
-- Solution to problem C 
-- EECS Programming Competition

import Data.List
import Data.Maybe

readLine1 :: IO (String,String)
readLine1 = getLine >>= return . break (==' ')

clean xs = let i = fromJust $ findIndex (==':') xs
             in (take i xs) ++ (drop (i+2) xs)

mk_list :: String -> [String]
mk_list xs | elem ' ' xs = let (y,ys) = break (==' ') xs in y:(mk_list $ tail ys)
           | otherwise = [xs]

readDep :: IO (String, [String])
readDep = getLine >>= return . (\xs -> (head xs, tail xs)) . mk_list . clean

type Table = [(String, [String])]

insert' :: Table -> (String, String) -> Table
insert' [] (l1, l2) = [(l1, [l2])]
insert' ((l, ls):xs) (l1,l2) | l1==l = (l1, l2:ls):xs
                             | otherwise = (l,ls):(insert' xs (l1,l2))

readGraph :: Int -> Table -> IO Table
readGraph 0 tb = return tb
readGraph m tb = do
   (l, ls) <- readDep
   let tb' = foldl (\tb' -> \l' -> insert' tb' (l',l)) tb ls
   readGraph (m-1) tb'

findDeps lib [] = []
findDeps lib ((l,ls):xs) | l==lib = ls
                         | otherwise = findDeps lib xs

tr :: [(String,[String])] -> String -> [String]
tr gr lib = (lib:) . concat . map (\l -> tr gr l) $ findDeps lib gr

main = do
   (n',lib') <- readLine1
   let n = read n' :: Int
   let lib = tail lib'
   graph <- readGraph n []
   let xs = delete lib . nub . sort . tr graph $ lib
   if length xs == 0 then
      putStrLn $ "A bug in library " ++ lib ++ " will not break any other libraries."
   else do
      let ys = foldr (\c -> \s -> c ++ "," ++ s) (last xs) (init xs)
      putStrLn $ "A bug in library " ++ lib ++ " will break libraries: " ++ ys
