(* ocamlc str.cma extLib.cma -I +extlib A.ml *)

open Str
open Std

let in_list l s =
  let r = Str.regexp (" "^s^" ") in
  let l'= " "^(String.concat " " l)^" " in
  try 
    let _ = Str.search_forward r l' 0 in true
  with Not_found -> false

let get_links s =
    let r = Str.regexp "<a href=\"" in
    let rec f i acc =
      try 
        let i1 = Str.search_forward r s i in
        let i2 = String.index_from s (i1+9) '\"' in 
        let s' = String.sub s (i1+9) (i2-i1-9) in
        if (in_list acc s') || (s.[i2+1] != '>') then (f i2 acc) else f i2 (s'::acc)
      with Not_found -> acc
    in 
    f 0 []

let main = 
  let inp = Std.input_all stdin in
  let l = List.sort String.compare (get_links inp) in
  if l = [] then print_endline "No links found" else
  List.iter print_endline l
