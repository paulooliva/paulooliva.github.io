{-
   Solution to Problem A of IX EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 9 January 2016
-}

import Data.Text
import Data.List

getLinks :: Text -> [Text]
getLinks html = if failed then [] else link : getLinks rest
   where
      (x,y) = breakOn (pack "<a href=\"") html
      (prelink, rest) = breakOn (pack ">") $ Data.Text.drop 9 y
      (link, trash) = breakOn (pack "\"") prelink
      failed = (y == empty) || (trash /= (pack "\""))

main = do
   html <- getContents
   -- Extract links
   let links = (Prelude.map unpack).getLinks.pack $ html
   -- Sort and remove duplicates
   let unique = nub.sort $ links
   if unique == [] then
      putStrLn "No links found"
   else 
      mapM_ putStrLn unique
