{-
   Solution to Problem F of IX EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 12 January 2016
-}

import Data.List
import Control.Applicative

-- [3,3,2] means 1 and 2 allocated room 3, and 2 allocated room 2
type Alloc = [Int]

type Graph = [(Int,Int)]

readNumbers :: IO [Int]
readNumbers = (map read) <$> words <$> getLine

happy :: Alloc -> (Int,Int) -> Bool
happy alloc (i,j) = (alloc !! (i-1)) /= (alloc !! (j-1))

-- Given allocation and constrain, decide whether all staff are happy
test :: Graph -> Alloc -> Bool
test graph alloc = and (map (happy alloc) graph)

main = do
   m <- readLn :: IO Int
   n <- readLn :: IO Int
   xs <- mapM (\i -> readNumbers) [1..n]
   let ys = zip [1..] xs
   let graph = [ (i,j) | (i,js) <- ys, j <- js ]
   let allocations = sequence (replicate n [1..m])
   let result = or $ map (test graph) allocations
   putStrLn $ if result then "YES" else "NO"