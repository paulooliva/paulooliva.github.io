module IntSet = Set.Make (struct type t = int let compare = compare end)
module IntMap = Map.Make (struct type t = int let compare = compare end)

let generate m n max =
(* m: number of rooms, n: numbers of staff *)
  let _ = Random.init 321449 in
  let rec fin i acc =
    if i=0 then "" else
    let x = (Random.int n)+1 in
    if List.exists (fun y -> x=y) acc then fin i acc else
      let acc = x::acc in
      let x = string_of_int x in
      if i=1 then x else x^" "^(fin (i-1) acc)
  in 
  let rec f i =
    let len = Random.int max in
    let len = if len < n then len else n-1 in
    let x = fin len [i] in
    if i=n then x else x^"\n"^(f (i+1))
  in 
  f 1

let parse_1 s0 c cst = 
  let rec f s acc =
    if s = "" then acc else
    let i = try String.index s c with Not_found -> -1 in
    if i = -1 then (cst s)::acc else
    let x = cst (String.sub s 0 i) in
    f (String.sub s (i+1) ((String.length s)-i-1)) (x::acc)
  in 
  List.rev (f s0 [])

let parse_in _ =
  let m = int_of_string (read_line()) in
  let n = int_of_string (read_line()) in
  let rec f i acc =
    let s = parse_1 (read_line()) ' ' int_of_string in
    let folder acc x = IntSet.add x acc in
    let z = List.fold_left folder IntSet.empty s in
    let acc' = IntMap.add i z acc in
    if i = n then acc' else f (i+1) acc'
  in
  (m, n, f 1 IntMap.empty)

let (m,n,h) = parse_in ()

let max_cnt c = IntMap.for_all (fun _ x -> x = m-1) c 

let inc_cnt c = 
  let folder k x (y,acc) =
    if y then (y,acc) else  
    if x < m-1 then (true,IntMap.add k (x+1) acc)
    else (false,IntMap.add k 0 acc)
  in 
  let (_,z) = IntMap.fold folder c (false,c) in z

let prn_cnt c = ()
(* IntMap.iter (fun k s -> print_endline ((string_of_int k)^":"^(string_of_int s))) c *)

let chk_cnt c =
  let f k x =
    let s = IntMap.find k h in
    let chk j = ((IntMap.find j c) != x) in
    IntSet.for_all chk s
  in 
  let z = IntMap.for_all f c in 
  if z then (prn_cnt c; true) else false

let main = 
  let rec f c =
    if chk_cnt c then true else 
    if max_cnt c then false else f (inc_cnt c)
  in 
  let cnt = IntMap.map (fun _ -> 0) h in
  print_endline (if f cnt then "YES" else "NO")
