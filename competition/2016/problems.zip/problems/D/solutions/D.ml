let break_nums s =
  let l = String.length s in
  let rec f i acc =
    if i = l then acc else
    if i = l-1 then (int_of_string (String.sub s i 1)) :: acc else
    if String.get s (i+1) = '0' then f (i+2) (10::acc) else
    f (i+1) ((int_of_string (String.sub s i 1))::acc)
  in 
  f 0 []

let main =
  let l = break_nums (read_line()) in
  let s = List.fold_left (fun x y -> x+y) 0 l in
  let d = List.length l in
  let x = (string_of_int (s/d)) in
  let s = (s mod d)*10 in
  let x = x ^ "." ^ (string_of_int (s/d)) in
  let s = (s mod d)*10 in
  let x'= s/d in
  let x = x ^ (string_of_int x') in
  print_endline x
