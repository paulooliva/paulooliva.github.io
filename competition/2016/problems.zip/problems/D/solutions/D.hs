{-
   Solution to Problem D of IX EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 7 January 2016
-}

import Data.Text
import Data.Char
import Text.Printf

splitAll :: Text -> Text -> [Text]
splitAll pat text =
   if y == empty then [x] else x : (splitAll pat (Data.Text.drop n y))
   where
      (x,y) = breakOn pat text
      n = Data.Text.length pat

main = do
   xs <- getContents
   let ys = splitAll (pack "10") (pack xs)
   let n = (Prelude.length ys) - 1  -- number of 10's
   let zs = (Prelude.map digitToInt).(Prelude.concat).(Prelude.map unpack) $ ys
   let n1 = (10 * n) + (sum zs)
   let n2 = n + Prelude.length zs
   let av = (fromIntegral n1) / (fromIntegral n2)
   printf "%.2f\n" (av::Float)
