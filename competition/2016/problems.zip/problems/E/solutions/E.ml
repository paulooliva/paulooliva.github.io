(*
   Solution to Problem E of IX EECS Programming Competition
   Solution by: Nikos Tz
   Date: 23 January 2016
*)

let generate n m max =
  let _ = Random.init 321449 in
  let rec fin i =
    let x = string_of_int (Random.int max) in
    if i=1 then x else x^" "^(fin (i-1))
  in 
  let rec f i =
    let x = fin m in
    if i=1 then x else x^"\n"^(f (i-1))
  in 
  f n

let parse_1 s0 c cst = 
  let rec f s acc =
    if s = "" then acc else
    let i = try String.index s c with Not_found -> -1 in
    if i = -1 then (cst s)::acc else
    let x = cst (String.sub s 0 i) in
    f (String.sub s (i+1) ((String.length s)-i-1)) (x::acc)
  in 
  List.rev (f s0 [])

let parse_in _ =
  let n :: m :: _ = parse_1 (read_line()) ' ' int_of_string in
  let rec f i acc =
    if i = 0 then acc else f (i-1) ((parse_1 (read_line()) ' ' int_of_string)::acc)
  in 
  (n, m, f n [])

let flip s =
  let rec f x acc = 
    if List.length (List.hd x) = 1 then (List.flatten x) :: acc else
    let (x1, x2) = List.split (List.map (fun (y::z) -> (y,z)) x) in 
      f x2 (x1::acc) 
  in 
  List.rev (f s [])

let abs x y = if x>y then x-y else y-x
let sum s = 
    let (x,y) = List.fold_left (fun (x,acc) y -> (y,acc+(abs x y))) (0,0) s in
    x+y 

let compute s =
  let folder acc s = acc + (sum s) in 
  List.fold_left folder 0 s

let main = 
  let (n,m,h) = parse_in() in
  let out = (compute h) + (compute (flip h)) in
  print_endline (string_of_int out)
