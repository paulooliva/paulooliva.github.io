{-
   Solution to Problem E of IX EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 12 January 2016
-}

import Data.List
import Control.Applicative

readNumbers :: IO [Int]
readNumbers = (map read) <$> words <$> getLine

readMap :: Int -> IO [[Int]]
readMap 0 = return []
readMap n = do
   x <- readNumbers
   xs <- readMap (n-1)
   return $ x : xs

f :: Int -> Int -> Int
f n m = abs $ n - m

diff :: [Int] -> [Int]
diff xs = zipWith f xs (tail xs)

main = do
   [n,m] <- readNumbers
   xs <- readMap n
   let sum1 = sum (xs !! 0)
   let sum2 = sum (xs !! (n-1))
   let sum3 = sum (map head xs)
   let sum4 = sum (map last xs)
   let rowDiff = sum.(map sum).(map diff) $ xs
   let colDiff = sum.(map sum).(map diff).transpose $ xs
   print $ sum1 + sum2 + sum3 + sum4 + rowDiff + colDiff
