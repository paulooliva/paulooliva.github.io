let parse s =
  let i = String.index s ',' in
  let x = String.sub s 1 (i-1) in
  let y = String.sub s (i+1) (String.length s-i-2) in
  (int_of_string x, int_of_string y)
  
let is_prime_naive x =
  let rec f i =
  if i = 1 then true else 
  if x mod i = 0 then false else f (i-1) in
  f (x-1)

let inp = read_line()
let main = 
  let (x,y) = parse inp in
  let rec f i j =
    if is_prime_naive j then 
    ( if i = 1 then j else f (i-1) (j+1) )
    else f i (j+1)
  in  
  let z = f x (y+1) in
  print_endline (string_of_int z)
