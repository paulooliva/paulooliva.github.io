#include <iostream>
#include <sstream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <utility>
#include <memory.h>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>

#define forn(i, n) for (int i = 0; i < (int)n; i++)
#define forkn(i, k, n) for (int i = (int)k; i < (int)n; i++)
#define forit(i, a) for (__typeof((a).begin()) i = (a).begin(); i != (a).end(); i++)
#define sz(a) ((int)(a).size())
#define pb push_back
#define mp make_pair
#define fi first
#define se second

using namespace std;

typedef long long ll;
typedef vector <int> vi;
typedef vector <ll> vll;
typedef vector <string> vs;
typedef pair <int,int> pii;
typedef pair <string,int> psi;
typedef map <string,int> msi;

template <class T> void relax(T &a, T b) { a = min(a, b); }
template <class T> void mrelax(T &a, T b) { a = max(a, b); }

const int L = 1000010;

char c[L];

int main()
{
    int n, m; scanf("(%d,%d)", &n, &m);

    c[0] = c[1] = 1;
    forkn(i, 2, L)
        if (!c[i])
            for (int j = 2; j*i < L; j++)
                c[j*i] = 1;

    forkn(i, m+1, L)
        if (!c[i])
        {
            --n;

            if (!n)
            {
                printf("%d\n", i);
                break;
            }
        }

    return 0;
}
