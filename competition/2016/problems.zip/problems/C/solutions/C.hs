{-
   Solution to Problem C of IX EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 8 January 2016
-}

import Data.List
import Data.Char

primes :: [Integer]
primes = sieve [2..]
   where sieve (p:xs) = p : sieve [x|x <- xs, x `mod` p > 0]

main = do
   (i,m) <- readLn :: IO (Int,Integer)
   print.(!!(i-1)).(dropWhile (<=m)) $ primes
