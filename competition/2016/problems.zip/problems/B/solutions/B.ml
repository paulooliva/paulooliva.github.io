let cde = int_of_string "0b01101110"

(* helper functions *)

let exp i j = int_of_float ((float_of_int i)**(float_of_int j))

let int_to_binary x =                                            
  let rec f i x =                                                  
  if i = -1 then "" else                                           
  let z = exp 2 i in                                               
  if x >= z then "1" ^ (f (i-1) (x-z))                              
  else "0" ^ (f (i-1) x) in                                        
  f 7 x

let xor_8 x i =
  let y = "0b" ^ (String.sub x (8*i) 8) in 
  let y = int_of_string y in              
  (lxor) y cde

let my_xor x = 
  let l = (String.length x)/8 in
  let rec f i =
    if i = l then "" else  
    (int_to_binary (xor_8 x i)) ^ f (i+1)
  in 
  f 0

(* main functions *)

let encode x =                                                        
  let z = ref("") in                                                    
  String.iter (fun c -> z := !z ^ (int_to_binary ((lxor) cde (Char.code c)))) x; !z

let decode x = 
  let l = (String.length x)/8 in
  let rec f i = 
    if i = l then "" else  
    (String.make 1 (Char.chr (xor_8 x i))) ^ f (i+1) 
  in 
  f 0

let main = 
  let inp = ref "" in
  try while true do inp := !inp ^ read_line() done
  with End_of_file -> print_endline (decode !inp)

