{-
   Solution to Problem B of IX EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 8 January 2016
-}

import Data.List
import Data.Char

break8 :: String -> [String]
break8 "" = []
break8 xs = y : (break8 ys)
   where (y,ys) = splitAt 8 xs

xor :: Char -> Char -> Char
xor '0' '0' = '0'
xor '0' '1' = '1'
xor '1' '0' = '1'
xor '1' '1' = '0'
xor _ _ = '0'

fxor :: String -> String
fxor xs = zipWith xor xs "01101110"

binStrToInt :: String -> Int
binStrToInt "" = 0
binStrToInt ('0':cs) = binStrToInt cs
binStrToInt ('1':cs) = (2^n) + (binStrToInt cs)
   where n = length cs

binToChar :: String -> Char
binToChar xs = chr.binStrToInt $ xs

main = do
   raw <- getContents
   let cypher = filter (/='\n') raw
   -- Break into blocks of 8
   let xs = break8 cypher
   let ys = map fxor xs
   let zs = map binToChar ys
   putStrLn zs