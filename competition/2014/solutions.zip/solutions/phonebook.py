""""Solution to the problem C (Phonebook) of VII EECS Programming competition.

:author: Dmitrijs Milajevs
:date: 31 January 2014

"""

from sys import stdin


def read_file(f):
    lines = iter(f)
    next(lines)

    for line in lines:
        name, date = line.split(', ')

        last_name = name.split()[-1]
        day, month, year = date.split('/')

        yield year, month, day, last_name, name


if __name__ == '__main__':
    records = read_file(stdin)

    records = sorted(records)

    for year, month, day, _, name in records:
        print '{0}, {1}/{2}/{3}'.format(name, day, month, year),
