/*
   Solution to Problem A (Bubble) of VII EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 28 January 2014
*/ 

#include <stdio.h>

int n;
int numbers[65536];
int scans;
int swaps;

void readInput(void)
{
	int i;
	
	scanf("%d", &n);
	for (i=0;i<n;i++) scanf("%d", numbers+i);
}

void process (void)
{
	int swapped = 1;
	int i;
	
	scans = swaps = 0;

	while (swapped == 1)
	{
		swapped = 0;
		for (i=0;i<n-1;i++) {
			if (numbers[i]>numbers[i+1]) {
				int z = numbers[i];
				numbers[i] = numbers[i+1];
				numbers[i+1] = z;
				swapped = 1;
				swaps++;
			}
		}
		scans++;
	}
}

int main(void)
{
	readInput();
    process();
    printf("Scans: %d\n", scans-1);
    printf("Total swaps: %d\n", swaps);
}
