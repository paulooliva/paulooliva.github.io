/*
   Solution to Problem D (Containers) of VII EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 28 January 2014
*/ 

#include <stdio.h>
#include <string.h>
#include <math.h>

int n;                   // number of containers
int s_dim[1000];         // small dimensions
int b_dim[1000];         // big dimensions

char graph[1000][1000];  // partial order of "fits in" relation

int convToInt(char *s) {
    int i, j;
    int k = strlen(s);
    char clean_s[20];
    int ret;
    
    for (i=j=0;i<k;i++) {
        if (s[i] != '.') {
            clean_s[j] = s[i];
            j++;
        }
    }
    clean_s[j] = 0;
    
    sscanf(clean_s, "%d", &ret);
    
    // printf("Read %s as %d\n", s, ret);
    
    return ret;
}

void readInput(void)
{
	int i;
    char xs[20], ys[20];
	float x, y;
	
	scanf("%d", &n);
    
	for (i=0;i<n;i++) 
	{
		scanf("%s %s", xs, ys);
        
        x = convToInt(xs);
        y = convToInt(ys);
        
		if (x < y)
		{
			s_dim[i] = floor(100.0 * x);
			b_dim[i] = floor(100.0 * y);
		}
		else
		{
			b_dim[i] = floor(100.0 * x);
			s_dim[i] = floor(100.0 * y);
		}
	}
}

// container i fits inside container j
int fitIn(i, j) {
	return (s_dim[i] < s_dim[j]) && (b_dim[i] < b_dim[j]);
}

void buildGraph(void) 
{
	int i, j, k;
	
	for (i=0;i<n;i++)
		for (j=0;j<n;j++)
		{
			graph[i][j] = 0;   // assume i does not fit in j
			if (fitIn(i,j)) {
				int flag = 1;
                // check if some other container fits in between
				for (k=0;k<n;k++) if (fitIn(i,k) && fitIn(k,j)) flag = 0;
				if (flag == 1) graph[i][j] = 1;
			}
		}
    
    /*
    // print graph
    for (i=0;i<n;i++) {
        for (j=0;j<n;j++) printf("%d", graph[i][j]);
        printf("\n");
    }
     */
    
}

int dfs(int i) {
	int j, tmp;
	int max = 0;
		
	for (j=0;j<n;j++)
		if (graph[i][j] == 1) {
			tmp = dfs(j);
			if (tmp > max) max = tmp;
		}
	return 1 + max;
}

void process (void) {
	int i;
	int value_max = 0;
	int value;
	
	for (i=0;i<n;i++) {
		value = dfs(i);
		if (value > value_max) value_max = value;
        // printf("Maximal chain from %d (%d,%d) is %d\n", i, s_dim[i], b_dim[i], value);
	}
	printf("%d\n", value_max);
}

int main(void)
{
	readInput();
	buildGraph();
	process();
}
