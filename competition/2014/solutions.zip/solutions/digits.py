""""Solution to the problem F (Digits) of VII EECS Programming competition.

:author: Dmitrijs Milajevs
:date: 31 January 2014

"""

from sys import stdin


if __name__ == '__main__':
    print sum(int(d) for d in stdin.readline().strip())
