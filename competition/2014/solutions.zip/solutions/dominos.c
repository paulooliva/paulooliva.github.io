/*
   Solution to Problem B (Dominos) of VII EECS Programming Competition
   Solution by: Paulo Oliva
   Date: 28 January 2014
*/ 

#include <stdio.h>

int n;                    // number of type types
int s_face[1000];         // smaller number of tile
int b_face[1000];         // bigger number of tile

#define MAX 7

int lengths[MAX][MAX];       // matrix recording longest length with ends i j

void addTile(int a, int b) 
{
	int i, j;
	int len_tmp[MAX][MAX];

	// printf("Processing tile [%d:%d]\n", a, b);

	// copy to tmp	
	for (i=0;i<MAX;i++)
		for (j=i;j<MAX;j++)
			len_tmp[i][j] = lengths[i][j];

	for(i=0;i<=a;i++)
		if (lengths[i][a] + 1 > len_tmp[i][b] && lengths[i][a] != 0) {
			len_tmp[i][b] = lengths[i][a] + 1; 
			// printf("  list [%d...%d] new length = %d\n", i, b, len_tmp[i][b]);
		}

	for(i=a+1;i<MAX;i++)
		if (b>i) 
		{
			if (lengths[a][i] + 1 > len_tmp[i][b] && lengths[a][i] != 0) {
				len_tmp[i][b] = lengths[a][i] + 1;
				// printf("  list [%d...%d] new length = %d\n", i, b, len_tmp[i][b]);
			}
		} else
		{
			if (lengths[a][i] + 1 > len_tmp[b][i] && lengths[a][i] != 0) {
				len_tmp[b][i] = lengths[a][i] + 1;
				// printf("  list [%d...%d] new length = %d\n", b, i, len_tmp[b][i]);
			}
		}

	if (a != b) 
	{
		for(i=0;i<=b;i++)
			if (lengths[i][b] + 1 > len_tmp[a][i] && lengths[i][b] != 0) {
				if (a<=i) 
				{
					len_tmp[a][i] = lengths[i][b] + 1;
					// printf("  list [%d...%d] new length = %d\n", a, i, len_tmp[a][i]);
				} else
				{
					len_tmp[i][a] = lengths[i][b] + 1;
					// printf("  list [%d...%d] new length = %d\n", i, a, len_tmp[i][a]);
				}
			}

		for(i=b+1;i<MAX;i++)
			if (lengths[b][i] + 1 > len_tmp[a][i] && lengths[b][i] != 0) {
				len_tmp[a][i] = lengths[b][i] + 1; 
				// printf("  list [%d...%d] new length = %d\n", a, i, len_tmp[a][i]);
			}
	}

	if (len_tmp[a][b]==0) {
		len_tmp[a][b] = 1; 
		// printf("  list [%d...%d] new length = %d\n", a, b, len_tmp[a][b]);
	}

	// copy back
	for (i=0;i<MAX;i++)
		for (j=i;j<MAX;j++)
			lengths[i][j] = len_tmp[i][j];
}

int main(void)
{
	int i, j;
	int a, b, c;
	char char1, char2, char3;
	char line[50];
	
	char input[30];
	
	scanf("%d", &n);

	for (i=0;i<MAX;i++)
		for (j=i;j<MAX;j++)
			lengths[i][j] = 0;

	for (i=0;i<n;i++)
	{	
		scanf("%s %d", line, &c);
		
		a = line[1] - 48;
		b = line[3] - 48;		
	
		for (j=0;j<c;j++) {
			if (a<b) addTile(a,b); else addTile(b,a);
		}
	}

	// find max length
	int max = 0;
	for (i=0;i<MAX;i++)
		for (j=i;j<MAX;j++)
			if (lengths[i][j] > max) max = lengths[i][j];

	printf("%d\n", max);
}
