""""Solution to the problem D (DNA) of VII EECS Programming competition.

:author: Dmitrijs Milajevs
:date: 31 January 2014

"""

import sys
from itertools import izip


def main():
    first = next(sys.stdin)
    second = next(sys.stdin)

    for position, pair in enumerate(izip(first, second), start=1):
        for a, b in pair, reversed(pair):
            if (a == 'A' and b != 'T') or (a == 'G' and b != 'C'):
                print 'First error at position {0}'.format(position)
                return

    else:
        print "No error detected"

if __name__ == '__main__':
    main()

