b :: [Int] -> [Int] -> Bool
b xs [] = True
b [] ys = False
b (x:xs) (y:ys) = if x==y then b xs ys else (x>y)

q6 :: [Int] -> [Int] -> [Int]
q6 [] ys = ys
q6 xs [] = xs
q6 xs ys = if b xs ys then
             (head xs):(q6 (tail xs) ys)
          else
             (head ys):(q6 xs (tail ys))

main = do
   xs <- readLn :: IO [Int]
   ys <- readLn :: IO [Int]
   putStrLn $ show $ q6 xs ys