import Data.List
import Data.Char

data Kind = More 
          | OneMore 
          | Twice 
            deriving (Eq,Show)

type Constraint = (Int,Kind,Int)
type Sharing = [Int]

breakSpace :: String -> [String]
breakSpace xs | not (elem ' ' xs) = [xs]
              | otherwise = let (y,ys) = break (==' ') xs in y : (breakSpace (tail ys))

readNumber :: IO Int
readNumber = do
    l <- getLine
    let [n,ns] = breakSpace l
    return.read $ n

readConstraint :: IO Constraint
readConstraint = do
    l <- getLine
    let xs = breakSpace l
    let i = read (xs !! 3) :: Int
    let j = read (last xs) :: Int
    let c = if xs!!6=="more" then More else
                (if xs!!6=="one" then OneMore else Twice)
    return (i,c,j)

constraints :: Int -> IO [Constraint]
constraints 0 = return []
constraints n = do
    x <- readConstraint
    xs <- constraints (n-1)
    return (x:xs)

valid :: Sharing -> [Constraint] -> Bool
valid s [] = True
valid s ((i,More,j):xs) = if s!!i>s!!j then valid s xs else False
valid s ((i,OneMore,j):xs) = if s!!i==1+(s!!j) then valid s xs else False
valid s ((i,Twice,j):xs) = if s!!i==2*(s!!j) then valid s xs else False

sharings :: Int -> Int -> [Sharing]
sharings 1 1 = [[1]]
sharings c 1 = [[c]]
sharings c n = [ k:s | k <- [1..(c-1)], s <- sharings (c-k) (n-1) ]

main = do
    n <- readNumber
    c <- readNumber
    nc <- readNumber
    cs <- constraints nc
    let ss = sharings c n
    putStrLn $ if null [ s | s <- ss, valid s cs ] then "No" else "Yes"
