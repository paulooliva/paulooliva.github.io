import java.util.Scanner;

public class B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
	   for (int i=2;i<=n;i++)
	      for (int j=i+1;j<=n;j++)
	         for (int k=j+1;k<=n;k++) 
	            if (j*k==i*k+i*j) 
	               System.out.format("(%d,%d,%d)\n",i,j,k);
	}
}
