""""Solution to the problem B (Unit fractions) of 2017 EECS Programming competition

:author: Paulo Oliva
:date: 21 February 2017

"""

from sys import stdin

if __name__ == '__main__':
    n = int(stdin.readline())
    xs = [ (x,y,z) for z in range(2,n+1) for y in range(2,z) for x in range(2,y) if y*z==x*z+x*y ]
    xs.sort()
    for x in xs:
        print('({0},{1},{2})'.format(x[0], x[1], x[2]))
