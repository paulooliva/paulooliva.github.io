#include <stdio.h>

int main(void) {
   int n;
   scanf("%d",&n);
   for (int i=2;i<=n;i++)
      for (int j=i+1;j<=n;j++)
         for (int k=j+1;k<=n;k++) {
            if (j*k==i*k+i*j) {
               printf("(%d,%d,%d)\n",i,j,k);
            }
         }
}