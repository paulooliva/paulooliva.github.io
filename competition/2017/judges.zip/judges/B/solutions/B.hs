import Data.List

main = do
   l <- getLine
   let n = read l :: Int
   let xs = [ (x,y,z) | z<-[2..n], y<-[2..z], x<-[2..(y-1)], y*z==x*z+x*y ]
   mapM_ (putStrLn.show) $ sort $ xs
