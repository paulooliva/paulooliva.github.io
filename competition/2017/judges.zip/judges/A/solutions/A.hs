import Data.List
import Debug.Trace

readNumbers :: IO (Int, Int)
readNumbers = do
   l <- getLine
   let (x,y) = break (==' ') l
   return (read x, read (tail y))

readPuzzle :: Int -> IO [String]
readPuzzle 0 = return []
readPuzzle n = do
   x <- getLine
   xs <- readPuzzle (n-1)
   return $ x:xs

update xs (i,j) = [ [ c' c i' j' | (j',c) <- zip [0..] l ] | (i',l) <- zip [0..] xs ]
   where c' c i' j' = if (i',j')==(i,j) then '*' else c

check :: (Int,Int) -> (Int,Int) -> [String] -> String -> Bool
check (n,m) (i,j) xs [] = True
check (n,m) (i,j) xs (c:w) = if test then False else rest
   where
      test = i<0 || j<0 || i>=n || j>=m || c/=(xs!!i)!!j
      next = [ (i+i',j+j') | i'<-[1,0,-1], j'<-[1,0,-1], i'/=0 || j'/=0 ]
      rest = or [ check (n,m) (i',j') (update xs (i,j)) w | (i',j')<-next ]

main = do 
   (n,m) <- readNumbers
   xs <- readPuzzle n
   _ <- getLine
   w <- getLine
   let test = or [ check (n,m) (i,j) xs w | i <- [0..(n-1)], j <- [0..(m-1)] ]
   putStrLn $ if test then "Yes" else "No"
