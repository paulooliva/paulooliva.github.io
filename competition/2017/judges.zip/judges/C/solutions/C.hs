import Data.List

main = do
   n <- readLn :: IO Float
   m <- readLn :: IO Float
   let i = ceiling.sqrt $ n
   let j = floor.sqrt $ m
   putStrLn.show $ j - i + 1