import Data.List

combine [] ys = ys
combine xs [] = xs
combine (x:xs) (y:ys) | x==y = combine xs ys
                      | x<y = x:(combine xs (y:ys))
                      | otherwise = y:(combine (x:xs) ys)

check :: [Int] -> IO ()
check xs = putStrLn $ if nub xs' == xs' then "OK" else "Duplicates!" 
    where xs' = sort xs

main = do
   xs <- readLn :: IO [Int]
   ys <- readLn :: IO [Int]
   let xs' = sort xs
   let ys' = sort ys
   let zs = combine xs' ys'
   putStrLn $ show $ zs
