from django.shortcuts import render, redirect
from django.utils import timezone
from django.http import HttpResponse, Http404
from django.template import RequestContext, loader
from django.db.models import Q
from mainapp.models import User, Message, Follow

appname = 'Social Network'

# decorator that tests whether user is logged in
def loggedin(f):
    def test(request):
        if 'username' in request.session:
            return f(request)
        else:
            return render(request, 'mainapp/not-logged-in.html', {})
    return test

def index(request):
    context = {
        'appname': appname,
    }
    return render(request, 'mainapp/index.html', context)

def signup(request):
    context = { 'appname': appname }
    return render(request, 'mainapp/signup.html', context)

def register(request):
    u = request.POST['username']
    p = request.POST['password']
    user = User(username=u, password=p)
    user.save()
    context = {
        'appname': appname,
        'username' : u
    }
    return render(request, 'mainapp/user-registered.html', context)

def login(request):
    if 'username' not in request.POST:
        context = { 'appname': appname }
        return render(request, 'mainapp/login.html', context)
    else:
        u = request.POST['username']
        p = request.POST['password']
        try:
            member = User.objects.get(username=u)
        except User.DoesNotExist:
            return HttpResponse("User does not exist")
        if p == member.password:
            request.session['username'] = u;
            return redirect(to='/messages/?view='+u)
        else:
            return HttpResponse("Wrong password") 

@loggedin
def friends(request):
    username = request.session['username']
    member_obj = User.objects.get(username=username)
    # list of people I'm following
    following = member_obj.follows.all()
    # list of people that are following me
    followers = [ follow.follower for follow in list(Follow.objects.filter(following=member_obj)) ]
    # render reponse
    context = {
        'appname': appname,
        'username': username,
        'members': members,
        'following': following,
        'followers': followers,
        'loggedin': True
    }
    return render(request, 'mainapp/friends.html', context)

@loggedin
def logout(request):
    if 'username' in request.session:
        u = request.session['username']
        request.session.flush()        
        context = {
            'appname': appname,
            'username': u
        }
        return render(request, 'mainapp/logout.html', context)
    else:
        raise Http404("Can't logout, you are not logged in")

def member(request, view_user):
    username = request.session['username']
    member = User.objects.get(username=view_user)

    if view_user == username:
        greeting = "Your"
    else:
        greeting = view_user + "'s"

    return render(request, 'mainapp/member.html', {
        'appname': appname,
        'username': username,
        'view_user': view_user,
        'greeting': greeting,
        'profile': '',
        'loggedin': True}
        )

@loggedin
def members(request):
    username = request.session['username']
    member_obj = User.objects.get(username=username)
    # follow new friend
    if 'add' in request.GET:
        friend = request.GET['add']
        friend_obj = User.objects.get(username=friend)
        follow = Follow(follower=member_obj, following=friend_obj)
        follow.save()
    # unfollow a friend
    if 'remove' in request.GET:
        friend = request.GET['remove']
        friend_obj = User.objects.get(username=friend)
        #member_obj.followings.remove(friend_obj)
        follow = Follow.objects.get(follower=member_obj,following=friend_obj)
        follow.delete()
    # view user profile
    if 'view' in request.GET:
        return member(request, request.GET['view'])
    else:
        # list of all other members
        members = User.objects.exclude(username=username)
        # list of people I'm following
        following = member_obj.follows.all()
        # list of people that are following me
        followers = [ follow.follower for follow in list(Follow.objects.filter(following=member_obj)) ] 
        # render reponse
        return render(request, 'mainapp/members.html', {
            'appname': appname,
            'username': username,
            'members': members,
            'following': following,
            'followers': followers,
            'loggedin': True}
            )

@loggedin
def messages(request):
    username = request.session['username']
    user = User.objects.get(username=username)
    # Whose message's are we viewing?
    if 'view' in request.GET:
        view = request.GET['view']
    else:
        view = username
    recip = User.objects.get(username=view)
    # If message was deleted
    if 'erase' in request.GET:
        msg_id = request.GET['erase']
        Message.objects.get(id=msg_id).delete()
    # If text was posted then save on DB
    if 'text' in request.POST:
        text = request.POST['text']
        message = Message(user_from=user,user_to=recip,text=text)
        message.save()
    messages = Message.objects.filter(Q(user_to=recip) | Q(user_from=recip)).order_by('id')
    return render(request, 'mainapp/messages.html', {
        'appname': appname,
        'username': username,
        'profile': '',
        'view': view,
        'messages': messages,
        'loggedin': True}
        )

def regCheckUser(request):
    if 'username' in request.POST:
        u = request.POST['username']
        try:
            member = User.objects.get(username=u)
            return HttpResponse("<span class='taken'>&nbsp;&#x2718; This username is taken</span>")
        except User.DoesNotExist:
            return HttpResponse("<span class='available'>&nbsp;&#x2714; This username is available</span>")
    else:
        return HttpResponse("Expected 'username' in request")

def logCheckUser(request):
    if 'username' in request.POST:
        u = request.POST['username']
        try:
            member = User.objects.get(username=u)
            return HttpResponse("<span class='available'>&nbsp;&#x2714; Valid username</span>")
        except User.DoesNotExist:
            return HttpResponse("<span class='taken'>&nbsp;&#x2718; Unknown username</span>")
    else:
        return HttpResponse("")
