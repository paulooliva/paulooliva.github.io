from django.db import models

class User(models.Model):
    username = models.CharField(max_length=16, unique=True)
    password = models.CharField(max_length=16)
    follows = models.ManyToManyField('self'
                      , through='Follow'
                      , through_fields=('follower', 'following')
                      , symmetrical=False
                      , related_name='followings'
                )
    sent = models.ManyToManyField('self'
                      , through='Message'
                      , through_fields=('user_from','user_to')
                      , symmetrical=False
                )

    class Meta:
        db_table = 'user'

class Follow(models.Model):
    follower = models.ForeignKey(User)
    following = models.ForeignKey(User, related_name='following')

    class Meta:
        db_table = 'following'

class Message(models.Model):
    user_from = models.ForeignKey(User)
    user_to = models.ForeignKey(User, related_name='received')
    text = models.CharField(max_length=4096)

    class Meta:
        db_table = 'message'
