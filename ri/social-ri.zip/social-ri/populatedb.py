#! /usr/bin/env python

# Setting DJANGO_SETTINGS_MODULE
import os
os.environ['DJANGO_SETTINGS_MODULE'] = 'socialnetwork.settings'

import django
import csv
import random

django.setup()

from mainapp.models import User, Follow, Message

with open('users.csv', 'r') as users_file:
   reader = csv.reader(users_file, delimiter=',', quotechar='"')
   names = []
   for row in reader:
      names.append(row[0].lower())
      names.sort()
   # Adding users to the database
   for name in names:
      user = User(username=name, password=name)
      user.save()
   # Adding random connections between users
   users = User.objects.all()
   for user1 in users:
      for user2 in users:
         if user1 != user2:
            r = random.randint(0,4)
            if r == 0:
               follow = Follow(follower=user1, following=user2)
               follow.save()
   with open('comments.csv', 'r') as comments_file:
      reader = csv.reader(comments_file, delimiter=',', quotechar='"')
      comments = []
      for row in reader:
         comments.append(row[0])
      # Adding random messages between users
      n = len(comments)
      print(n, 'messages')
      for user1 in users:
         for user2 in users:
            if user1 != user2:
               r = random.randint(0,3)
               if r == 0:
                  i = random.randint(0,n-1)
                  print(' - adding',i)
                  follow = Message(user_from=user1, user_to=user2, text=comments[i])
                  follow.save()
      print(comments)




